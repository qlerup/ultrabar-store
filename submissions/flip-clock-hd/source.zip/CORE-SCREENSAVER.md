# Core screensaver contract 1

UltraBar Studio 0.52.30 supports Core-side screensavers from reviewed first-party
Store packages. The Studio installer support is shared by packages. Each
screensaver app owns its display, idle policy and input handling on Core.

A package needs these pieces.

- A signed `corebar-app` Store release from the approved publisher.
- `assets/core-screensaver.json` containing `{"api":1}` in the APK.
- An enabled, exported `<package>.CoreScreensaverService` protected by
  `android.permission.BIND_ACCESSIBILITY_SERVICE` and registered under the Android
  accessibility service intent action.
- Service metadata that points to `@xml/core_screensaver`. Set
  `canRetrieveWindowContent="false"`. Use the narrowest event subscription
  appropriate for your timer. Flip Clock HD uses window change timing and a
  transparent one-pixel listener for touch events outside the overlay.
- The existing Store settings API for settings users can edit in Studio.
  The app must store configuration on Core and run with no Windows process.

Add only one screensaver to a layout. Deploy installs the APK, applies its
settings, disables LineOS' own idle screensaver and asks Android to activate
the selected service. The previous selection is saved on Core. Removing the
screensaver from the layout and deploying restores the previous LineOS choice.

A new reviewed package that uses this contract can be added through the usual
Store PR workflow without changing Studio.
