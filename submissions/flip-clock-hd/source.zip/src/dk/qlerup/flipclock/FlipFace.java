package dk.qlerup.flipclock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

final class FlipFace extends View {
    private static final int FLIP_MS = 470;
    private static final Typeface NUMERAL = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private static final Typeface DAY = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private static final Typeface DATE = Typeface.create("sans-serif-light", Typeface.NORMAL);
    private final Paint photo = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Paint shade = new Paint();
    private final Rect half = new Rect();
    private final Rect glyph = new Rect();
    private final Rect artwork = new Rect(0, 0, ClockTheme.ART_WIDTH, ClockTheme.ART_HEIGHT);
    private final Locale locale;
    private final DateTimeFormatter weekday;
    private final DateTimeFormatter date;
    private final Runnable ticker = this::tick;
    private ClockTheme theme;
    private ClockTheme.Plates plates;
    private Bitmap image;
    private boolean use24Hour;
    private boolean showDate;
    private boolean showSeconds;
    private String oldTime = "";
    private String time = "";
    private String weekdayText = "";
    private String dateText = "";
    private long transition;

    FlipFace(Context context) {
        super(context);
        locale = getResources().getConfiguration().getLocales().get(0);
        weekday = DateTimeFormatter.ofPattern("EEEE", locale);
        date = DateTimeFormatter.ofPattern("d MMM", locale);
        text.setTextAlign(Paint.Align.CENTER);
    }

    void configure(ClockTheme theme, boolean use24Hour, boolean showDate, boolean showSeconds) {
        if (this.theme != theme || this.showSeconds != showSeconds) {
            String asset = "themes/" + theme.asset + (showSeconds ? "-seconds.webp" : ".webp");
            try (InputStream stream = getContext().getAssets().open(asset)) {
                image = BitmapFactory.decodeStream(stream);
            } catch (IOException error) {
                throw new IllegalStateException("Missing clock artwork", error);
            }
            this.theme = theme;
            this.plates = showSeconds ? theme.seconds : theme.minutes;
            this.showSeconds = showSeconds;
            time = "";
        }
        this.use24Hour = use24Hour;
        this.showDate = showDate;
        refresh(LocalDateTime.now());
        invalidate();
    }

    private void refresh(LocalDateTime now) {
        int hour = now.getHour();
        if (!use24Hour) hour = (hour + 11) % 12 + 1;
        int minute = now.getMinute();
        String next = showSeconds
                ? String.format(Locale.ROOT, "%02d%02d%02d", hour, minute, now.getSecond())
                : String.format(Locale.ROOT, "%02d%02d", hour, minute);
        String nextWeekday = now.format(weekday).toUpperCase(locale);
        String nextDate = now.format(date);
        if (!next.equals(time)) {
            oldTime = time.isEmpty() ? next : time;
            time = next;
            transition = SystemClock.uptimeMillis();
            String spokenTime = time.substring(0, 2) + ":" + time.substring(2, 4);
            if (showSeconds) spokenTime += ":" + time.substring(4);
            setContentDescription(spokenTime + " " + nextDate);
            invalidate();
        }
        if (!nextDate.equals(dateText)) {
            weekdayText = nextWeekday;
            dateText = nextDate;
            invalidate();
        }
    }

    private void tick() {
        refresh(LocalDateTime.now());
        postDelayed(ticker, 1000 - System.currentTimeMillis() % 1000);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        tick();
    }

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(ticker);
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (image == null) return;
        canvas.drawColor(0xff131416);
        float width = Math.min(getWidth(), getHeight() * (1424f / 280f));
        float height = width * (280f / 1424f);
        canvas.save();
        canvas.translate((getWidth() - width) / 2, (getHeight() - height) / 2);
        canvas.scale(width / artwork.width(), height / artwork.height());
        canvas.drawBitmap(image, null, artwork, photo);
        if (showDate) drawDate(canvas);
        float progress = Math.min(1f, (SystemClock.uptimeMillis() - transition) / (float) FLIP_MS);
        boolean animating = false;
        for (int i = 0; i < plates.bounds.length; i++) {
            char oldDigit = oldTime.charAt(i);
            char digit = time.charAt(i);
            Rect plate = plates.bounds[i];
            if (progress < 1f && oldDigit != digit) {
                animating = true;
                drawFlip(canvas, plate, oldDigit, digit, progress);
            } else {
                drawHalf(canvas, plate, digit, true);
                drawHalf(canvas, plate, digit, false);
            }
        }
        canvas.restore();
        if (animating) postInvalidateOnAnimation();
    }

    private void drawDate(Canvas canvas) {
        text.clearShadowLayer();
        text.setColor(theme.dateColor);
        text.setTypeface(DAY);
        text.setTextScaleX(1f);
        text.setTextSize(31);
        canvas.drawText(weekdayText, 265, plates.hinge - 13, text);
        text.setTypeface(DATE);
        text.setTextSize(56);
        canvas.drawText(dateText, 265, plates.hinge + 61, text);
    }

    private void drawFlip(Canvas canvas, Rect plate, char previous, char next, float progress) {
        drawHalf(canvas, plate, next, true);
        drawHalf(canvas, plate, previous, false);
        boolean upper = progress < 0.5f;
        float flatten = Math.abs((float) Math.cos(Math.PI * progress));
        half.set(plate.left + 5, upper ? plate.top + 5 : plates.hinge + 2,
                plate.right - 5, upper ? plates.hinge - 2 : plate.bottom - 5);
        canvas.save();
        canvas.scale(1 + (1 - flatten) * 0.035f, Math.max(0.02f, flatten),
                plate.exactCenterX(), plates.hinge);
        canvas.clipRect(half);
        canvas.drawBitmap(image, half, half, photo);
        drawDigit(canvas, plate, upper ? previous : next);
        shade.setColor(((int) ((1f - flatten) * 94)) << 24);
        canvas.drawRect(half, shade);
        canvas.restore();
    }

    private void drawHalf(Canvas canvas, Rect plate, char value, boolean upper) {
        canvas.save();
        canvas.clipRect(plate.left, upper ? plate.top : plates.hinge + 3,
                plate.right, upper ? plates.hinge - 3 : plate.bottom);
        drawDigit(canvas, plate, value);
        canvas.restore();
    }

    private void drawDigit(Canvas canvas, Rect plate, char value) {
        text.setTypeface(NUMERAL);
        text.setColor(theme.glyphColor);
        text.setShadowLayer(1.6f, 0, 1.8f, theme == ClockTheme.IVORY ? 0x52fff6e3 : 0x88000000);
        text.setTextScaleX(1.07f);
        text.setTextSize(plate.height() * 0.86f);
        String digit = String.valueOf(value);
        text.getTextBounds(digit, 0, 1, glyph);
        float baseline = plates.hinge - glyph.exactCenterY();
        canvas.drawText(digit, plate.exactCenterX(), baseline, text);
    }
}
