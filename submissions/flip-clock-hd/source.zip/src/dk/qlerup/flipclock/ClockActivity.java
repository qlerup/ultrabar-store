package dk.qlerup.flipclock;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.MotionEvent;
import android.view.View;
import java.lang.ref.WeakReference;

public final class ClockActivity extends Activity {
    private static WeakReference<ClockActivity> visible = new WeakReference<>(null);
    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };
    private boolean listening;
    private FlipFace clock;
    private boolean use24Hour;
    private final SharedPreferences.OnSharedPreferenceChangeListener settings =
            (preferences, key) -> configureClock();

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        Uri uri = getIntent().getData();
        boolean launcher = Intent.ACTION_MAIN.equals(getIntent().getAction()) && uri == null;
        if (!launcher && (uri == null || !uri.isHierarchical() || !"screensaver".equals(uri.getScheme())
                || !"ultra-flip-hd".equals(uri.getHost()) || !"/start".equals(uri.getPath()))) {
            finish();
            return;
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        String mode = uri == null ? null : uri.getQueryParameter("24h");
        use24Hour = mode == null ? DateFormat.is24HourFormat(this) : "1".equals(mode);
        clock = new FlipFace(this);
        configureClock();
        clock.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) dismiss();
            return true;
        });
        setContentView(clock);
        registerReceiver(screenOff, new IntentFilter(Intent.ACTION_SCREEN_OFF));
        listening = true;
        visible = new WeakReference<>(this);
        ClockTheme.prefs(this).registerOnSharedPreferenceChangeListener(settings);
    }

    private void configureClock() {
        clock.configure(ClockTheme.selected(this), use24Hour,
                ClockTheme.prefs(this).getBoolean("showDate", true),
                ClockTheme.prefs(this).getBoolean("showSeconds", false));
    }

    static void stopVisibleClock() {
        ClockActivity activity = visible.get();
        if (activity != null) activity.dismiss();
    }

    private void dismiss() {
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    public void onBackPressed() {
        dismiss();
    }

    @Override
    protected void onDestroy() {
        if (visible.get() == this) visible.clear();
        if (listening) {
            unregisterReceiver(screenOff);
            ClockTheme.prefs(this).unregisterOnSharedPreferenceChangeListener(settings);
            sendBroadcast(new Intent("com.ultrabar.EXIT_SCREENSAVER").setPackage("com.ultrabar.launch")
                    .putExtra("appId", getPackageName()));
        }
        super.onDestroy();
    }
}
