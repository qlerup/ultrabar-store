package dk.qlerup.flipclock;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;

enum ClockTheme {
    GRAPHITE("graphite", 0xfff6eadb, 0xffcbbca9,
            new Plates(162, 346, 532, 556, 915, 938, 1297, 1363, 1722, 1744, 2102),
            new Plates(162, 345, 530, 558, 788, 805, 1036, 1098, 1326, 1342, 1572,
                    1634, 1866, 1881, 2108)),
    IVORY("ivory", 0xff42352c, 0xff544237,
            new Plates(193, 361, 526, 606, 945, 966, 1305, 1378, 1715, 1737, 2073),
            new Plates(193, 360, 527, 606, 818, 840, 1048, 1120, 1330, 1350, 1558,
                    1632, 1842, 1862, 2076)),
    MIDNIGHT("midnight", 0xffdceeff, 0xffa3c1d5,
            new Plates(194, 359, 532, 565, 917, 938, 1291, 1355, 1707, 1728, 2082),
            new Plates(192, 357, 530, 562, 792, 806, 1036, 1088, 1316, 1334, 1560,
                    1612, 1838, 1858, 2084));

    static final int ART_WIDTH = 2172;
    static final int ART_TOP = 94;
    static final int ART_HEIGHT = 568;
    final String asset;
    final int glyphColor;
    final int dateColor;
    final Plates minutes;
    final Plates seconds;

    ClockTheme(String asset, int glyphColor, int dateColor, Plates minutes, Plates seconds) {
        this.asset = asset;
        this.glyphColor = glyphColor;
        this.dateColor = dateColor;
        this.minutes = minutes;
        this.seconds = seconds;
    }

    static final class Plates {
        final Rect[] bounds;
        final int hinge;

        Plates(int top, int hinge, int bottom, int... sides) {
            this.hinge = hinge - ART_TOP;
            bounds = new Rect[sides.length / 2];
            for (int index = 0; index < bounds.length; index++) {
                bounds[index] = new Rect(sides[index * 2], top - ART_TOP,
                        sides[index * 2 + 1], bottom - ART_TOP);
            }
        }
    }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences("clock", Context.MODE_PRIVATE);
    }

    static ClockTheme selected(Context context) {
        try {
            return valueOf(prefs(context).getString("theme", GRAPHITE.name()));
        } catch (IllegalArgumentException invalid) {
            return GRAPHITE;
        }
    }
}
