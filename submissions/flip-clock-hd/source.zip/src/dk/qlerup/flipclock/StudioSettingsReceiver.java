package dk.qlerup.flipclock;
import android.content.Context;
import org.json.JSONObject;
import studio.settings.StudioSettingsBridge;

public final class StudioSettingsReceiver extends StudioSettingsBridge {
    @Override
    protected JSONObject readValues(Context context, JSONObject schema) throws Exception {
        return new JSONObject()
                .put("theme", ClockTheme.selected(context).name())
                .put("showDate", ClockTheme.prefs(context).getBoolean("showDate", true))
                .put("showSeconds", ClockTheme.prefs(context).getBoolean("showSeconds", false))
                .put("idleDelay", ClockTheme.prefs(context).getString("idleDelay", "60"));
    }

    @Override
    protected void applyValues(Context context, JSONObject values) throws Exception {
        if (!ClockTheme.prefs(context).edit().putString("theme", values.getString("theme"))
                .putBoolean("showDate", values.getBoolean("showDate"))
                .putBoolean("showSeconds", values.getBoolean("showSeconds"))
                .putString("idleDelay", values.getString("idleDelay")).commit()) {
            throw new IllegalStateException("Clock settings could not be saved");
        }
    }
}
