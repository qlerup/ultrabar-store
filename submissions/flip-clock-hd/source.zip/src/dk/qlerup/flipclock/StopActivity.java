package dk.qlerup.flipclock;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public final class StopActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Uri uri = getIntent().getData();
        if (Intent.ACTION_VIEW.equals(getIntent().getAction()) && uri != null
                && "screensaver".equals(uri.getScheme()) && "ultra-flip-hd".equals(uri.getHost())
                && "/stop".equals(uri.getPath())) {
            ClockActivity.stopVisibleClock();
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
