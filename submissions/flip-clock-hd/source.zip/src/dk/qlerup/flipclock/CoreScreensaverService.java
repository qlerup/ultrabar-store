package dk.qlerup.flipclock;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/** Local, touch-driven idle clock. The service cannot inspect other apps' views. */
public final class CoreScreensaverService extends AccessibilityService {
    private static CoreScreensaverService connected;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable idle = this::showClock;
    private final SharedPreferences.OnSharedPreferenceChangeListener settings =
            (preferences, key) -> { if ("idleDelay".equals(key)) arm(); };
    private final BroadcastReceiver display = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) handler.removeCallbacks(idle);
            else arm();
        }
    };
    private View touchWatcher;
    private WindowManager windows;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        if (connected == this) return;
        windows = getSystemService(WindowManager.class);
        touchWatcher = new View(this);
        touchWatcher.setOnTouchListener((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_OUTSIDE
                    || event.getActionMasked() == MotionEvent.ACTION_DOWN) arm();
            return false;
        });
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(1, 1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.RIGHT;
        windows.addView(touchWatcher, params);
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(display, filter);
        ClockTheme.prefs(this).registerOnSharedPreferenceChangeListener(settings);
        connected = this;
        arm();
    }

    static void clockVisibilityChanged() {
        if (connected != null) connected.arm();
    }

    private void arm() {
        handler.removeCallbacks(idle);
        if (ClockActivity.isVisible() || !getSystemService(PowerManager.class).isInteractive()) return;
        long delay = Long.parseLong(ClockTheme.prefs(this).getString("idleDelay", "60")) * 1000;
        handler.postDelayed(idle, delay);
    }

    private void showClock() {
        if (ClockActivity.isVisible() || !getSystemService(PowerManager.class).isInteractive()
                || getSystemService(KeyguardManager.class).isKeyguardLocked()) return;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("screensaver://ultra-flip-hd/start"),
                this, ClockActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        arm(); // Only the event timing is used. No accessibility content is read.
    }

    @Override public void onInterrupt() {}

    @Override public void onDestroy() {
        if (connected == this) {
            connected = null;
            handler.removeCallbacks(idle);
            unregisterReceiver(display);
            ClockTheme.prefs(this).unregisterOnSharedPreferenceChangeListener(settings);
            windows.removeViewImmediate(touchWatcher);
            ClockActivity.stopVisibleClock();
        }
        super.onDestroy();
    }
}
